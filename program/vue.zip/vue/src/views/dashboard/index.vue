<template>
    <div class="dashboard-container">

        <div
            title="欢迎页面"
            style="
                overflow: hidden;
                color: black;
                background-color: #eee;
                font: lighter 34px 'Lucida Sans Unicode';
            "
            id="index-title"
            data-options="iconCls:'icon-heart',plain:true"
        >
            
            
            
            <b style="font-size: 50px">
                欢迎来到湘潭大学线上图书馆
            </b>
             <img src="@/assets/index.jpg" style="width: 100%;opacity: .8" />
        </div>

    </div>
</template>

<script>
import { mapGetters } from "vuex";


export default {
    name: "Dashboard",
    computed: {
        ...mapGetters(["id", "name", "roles"]),
    },
    mounted() {
        
    }
};
</script>
